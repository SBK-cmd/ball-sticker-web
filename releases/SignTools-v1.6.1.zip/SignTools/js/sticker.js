/* Sign Tools — เรียงสติ๊กเกอร์ลงแผ่น + เส้น kiss cut */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var MM0 = 72 / 25.4, MM = MM0;   // MM = หน่วยสคริปต์ต่อ 1 มม. (ไฟล์ Large Canvas หาร 10)
  var COLORS = ['#ffd23f', '#7fd3ef', '#ff6fa0', '#6fdc9a', '#b38cff', '#ff9f5a', '#5ab0ff', '#e6e6e6'];

  function esc(v) {
    return JSON.stringify(v).replace(/[\u007f-￿]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); });
  }
  function host(fn, arg) {
    return new Promise(function (resolve) {
      if (!window.__adobe_cep__) return resolve({ error: 'ไม่ได้รันใน Illustrator' });
      window.__adobe_cep__.evalScript(fn + '(' + (arg === undefined ? '' : esc(arg)) + ')', function (r) {
        try { resolve(JSON.parse(r)); } catch (e) { resolve({ error: 'สคริปต์ผิดพลาด: ' + r }); }
      });
    });
  }
  var toastT;
  function toast(t) { var el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, 3200); }
  function num(id, d) { var v = parseFloat($(id).value); return isNaN(v) ? d : v; }
  function mode() { var b = document.querySelector('.seg[data-name="stkMode"] .on'); return b ? b.dataset.v : 'fill'; }
  function fmt(mm) { return (Math.round(mm * 10) / 10).toString(); }

  var items = [], qty = {}, result = null, page = 0;

  // ---------- ขนาดเส้นตัดของแต่ละลาย (มม.) ----------
  function cutSize(it) {
    var cut = $('stkCut').value, off = Math.max(0, num('stkOff', 0));
    var b = (cut === 'own' && it.cut) ? it.cut : it.vb;
    var w = (b[2] - b[0]) / MM, h = (b[1] - b[3]) / MM;
    if (cut === 'own' && it.cut) return { w: w, h: h };
    if (cut === 'own') return { w: w + 2 * off, h: h + 2 * off };        // ไม่มีเส้น → สี่เหลี่ยมแทน
    if (cut === 'circle') { var d = Math.max(w, h) + 2 * off; return { w: d, h: d }; }
    return { w: w + 2 * off, h: h + 2 * off };
  }
  function sheetSize() {
    var v = $('stkSheet').value, w, h;
    if (v === 'custom') return { w: Math.max(20, num('stkW', 210)), h: Math.max(20, num('stkH', 297)) };   // ใช้ตามที่พิมพ์
    var p = v.split('x'); w = +p[0]; h = +p[1];
    if ($('stkOrient').value === 'l') { var t = w; w = Math.max(w, h); h = Math.min(t, h); }
    else { var t2 = w; w = Math.min(w, h); h = Math.max(t2, h); }
    return { w: w, h: h };
  }

  // ---------- คำนวณ + แสดงตัวอย่าง ----------
  function recalc() {
    var custom = $('stkSheet').value === 'custom', isRect = $('stkCut').value === 'rect';
    document.querySelectorAll('#tab-stk .onlyCustom').forEach(function (e) { e.classList.toggle('hidden', !custom); });
    $('stkOrient').parentNode.classList.toggle('hidden', custom);
    document.querySelectorAll('#tab-stk .onlyRect').forEach(function (e) { e.classList.toggle('hidden', !isRect); });
    var m = mode();
    renderList(m);
    result = null; page = 0;
    if (!items.length) { $('stkRes').textContent = 'ยังไม่มีสติ๊กเกอร์'; $('stkGo').disabled = true; draw(); return; }
    var sh = sheetSize();
    var list = (m === 'fill' ? [items[0]] : items).map(function (it, i) {
      var s = cutSize(it);
      return { w: s.w * MM, h: s.h * MM, qty: m === 'fill' ? 0 : (qty[i] == null ? 10 : qty[i]) };
    });
    result = STPack.pack({ sheetW: sh.w * MM, sheetH: sh.h * MM, margin: Math.max(0, num('stkMargin', 5)) * MM,
      gap: Math.max(0, num('stkGap', 3)) * MM, rotate: $('stkRot').checked, fill: m === 'fill', items: list });
    var msg = '', sub = '';
    if (result.error) msg = '⚠ ' + result.error;
    else if (m === 'fill') {
      msg = result.perSheet ? 'ได้ ' + result.perSheet + ' ดวง / แผ่น' : '⚠ สติ๊กเกอร์ใหญ่กว่าแผ่น';
      var s0 = cutSize(items[0]); sub = 'ขนาดเส้นตัด ' + fmt(s0.w) + ' × ' + fmt(s0.h) + ' มม. · แผ่น ' + sh.w + ' × ' + sh.h + ' มม.';
      if (items.length > 1) sub += ' · ใช้ลายแรกเท่านั้น (เปลี่ยนเป็น "หลายลาย" เพื่อใช้ทุกลาย)';
    } else {
      var want = list.reduce(function (a, x) { return a + x.qty; }, 0);
      msg = result.sheets.length + ' แผ่น · ' + result.placed + ' ดวง';
      var parts = result.sheets.slice(0, 6).map(function (s, i) { return 'แผ่น ' + (i + 1) + ': ' + s.length; });
      if (result.sheets.length > 6) parts.push('…');
      sub = parts.join(' · ');
      if (result.sheets.length > 20) sub += ' · ⚠ จำนวนแผ่นเยอะมาก ตรวจขนาดแผ่น/จำนวนดวงอีกครั้ง';
      if (result.placed < want && !result.tooBig.length) sub += ' · ⚠ วางได้ไม่ครบ';
    }
    if (result.tooBig && result.tooBig.length) sub += ' · ⚠ ใหญ่เกินแผ่น: ' + result.tooBig.map(function (d) { return items[d].name; }).join(', ');
    $('stkRes').innerHTML = '';
    $('stkRes').appendChild(document.createTextNode(msg));
    var sm = document.createElement('small'); sm.textContent = sub; $('stkRes').appendChild(sm);
    $('stkGo').disabled = !(result && result.placed);
    draw();
  }

  function renderList(m) {
    var box = $('stkList'); box.innerHTML = '';
    items.forEach(function (it, i) {
      var s = cutSize(it), row = document.createElement('div'); row.className = 'stkrow';
      if (m === 'fill' && i > 0) row.style.opacity = '.45';
      row.innerHTML = '<span class="dot"></span><span class="nm"></span><span class="sz"></span>';
      row.querySelector('.dot').style.background = COLORS[i % COLORS.length];
      row.querySelector('.nm').textContent = it.name + (it.raster ? ' · ภาพ' : '') + (it.cut ? ' · มีเส้นตัด' : '');
      row.querySelector('.sz').textContent = fmt(s.w) + '×' + fmt(s.h) + ' มม.';
      if (m === 'multi') {
        var q = document.createElement('input'); q.type = 'number'; q.min = '0'; q.value = qty[i] == null ? 10 : qty[i]; q.title = 'จำนวนดวง';
        q.oninput = function () { qty[i] = Math.max(0, Math.floor(+q.value || 0)); recalcSoon(); };
        row.appendChild(q);
      }
      box.appendChild(row);
    });
  }
  var rt; function recalcSoon() { clearTimeout(rt); rt = setTimeout(recalcKeepFocus, 120); }
  function recalcKeepFocus() {
    var a = document.activeElement, idx = -1, rows = Array.prototype.slice.call(document.querySelectorAll('#stkList input'));
    idx = rows.indexOf(a);
    recalc();
    if (idx >= 0) { var n = document.querySelectorAll('#stkList input')[idx]; if (n) { n.focus(); try { n.setSelectionRange(n.value.length, n.value.length); } catch (e) {} } }
  }

  function draw() {
    var cv = $('stkCanvas'), ctx = cv.getContext('2d'), sh = sheetSize();
    var maxW = 300, maxH = 400, k = Math.min(maxW / sh.w, maxH / sh.h);
    cv.width = Math.round(sh.w * k); cv.height = Math.round(sh.h * k);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, cv.width, cv.height);
    var mg = Math.max(0, num('stkMargin', 5)) * k;
    ctx.setLineDash([4, 3]); ctx.strokeStyle = '#c8c8c8'; ctx.lineWidth = 1;
    ctx.strokeRect(mg + .5, mg + .5, cv.width - 2 * mg - 1, cv.height - 2 * mg - 1); ctx.setLineDash([]);
    var sheets = result && result.sheets || [];
    $('stkNav').classList.toggle('hidden', sheets.length < 2);
    $('stkPage').textContent = sheets.length ? 'แผ่น ' + (page + 1) + ' / ' + sheets.length : '';
    var s = sheets[page] || [], cut = $('stkCut').value, rad = Math.max(0, num('stkRad', 3));
    var kp = k / MM;
    s.forEach(function (p) {
      var x = p.x * kp, y = p.y * kp, w = p.w * kp, h = p.h * kp;
      ctx.fillStyle = COLORS[p.d % COLORS.length] + '55';
      ctx.strokeStyle = '#ec008c'; ctx.lineWidth = 1;
      ctx.beginPath();
      if (cut === 'circle' || cut === 'ellipse') ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      else {
        var r = cut === 'rect' ? Math.min(rad * k, w / 2, h / 2) : Math.min(2 * k, w / 4, h / 4);
        ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
      }
      ctx.fill(); ctx.stroke();
    });
  }

  // ---------- คำสั่ง ----------
  $('stkRead').onclick = function () {
    host('st_stkRead').then(function (r) {
      if (r.error) { toast('⚠ ' + r.error); return; }
      items = r.items; qty = {};
      MM = MM0 / (r.sf || 1);
      $('stkHint').textContent = 'อ่านได้ ' + items.length + ' ลาย' + (r.sf > 1 ? ' · ไฟล์ Large Canvas (สเกล 1:' + r.sf + ')' : '') + (items.length > 1 && mode() === 'fill' ? ' — เลือก "หลายลาย" เพื่อใส่จำนวนแต่ละลาย' : '');
      $('stkWarn').textContent = '';
      recalc();
    });
  };
  $('stkGo').onclick = function () {
    if (!result || !result.placed) return;
    var sh = sheetSize(), go = $('stkGo');
    go.disabled = true; go.textContent = 'กำลังสร้าง… (ลายเยอะอาจใช้เวลาสักครู่)'; $('stkWarn').textContent = '';
    var sheets = result.sheets.map(function (s) { return s.map(function (p) { return { d: p.d, x: p.x, y: p.y, r: p.r }; }); });
    host('st_stkPlace', {
      cutType: $('stkCut').value, offsetMM: Math.max(0, num('stkOff', 0)), radiusMM: Math.max(0, num('stkRad', 0)),
      sheetW: sh.w * MM, sheetH: sh.h * MM, count: items.length, sheets: sheets
    }).then(function (r) {
      go.disabled = false; go.textContent = '② สร้างแผ่นงาน';
      if (r.error) { toast('⚠ ' + r.error); $('stkWarn').textContent = '⚠ ' + r.error; return; }
      toast('✓ ' + r.msg);
      if (r.warn && r.warn.length) $('stkWarn').textContent = '⚠ ' + r.warn.join(' · ');
    });
  };
  $('stkPrev').onclick = function () { if (page > 0) { page--; draw(); } };
  $('stkNext').onclick = function () { if (result && page < result.sheets.length - 1) { page++; draw(); } };

  ['stkCut', 'stkOff', 'stkRad', 'stkGap', 'stkSheet', 'stkOrient', 'stkW', 'stkH', 'stkMargin', 'stkRot'].forEach(function (id) {
    $(id).addEventListener('input', recalcSoon); $(id).addEventListener('change', recalcSoon);
  });
  document.querySelectorAll('.seg[data-name="stkMode"] button').forEach(function (b) { b.addEventListener('click', function () { setTimeout(recalc, 0); }); });
  setTimeout(recalc, 0);

  window.__stk = { setItems: function (x) { items = x; qty = {}; recalc(); }, result: function () { return result; } };   // สำหรับทดสอบ
})();
