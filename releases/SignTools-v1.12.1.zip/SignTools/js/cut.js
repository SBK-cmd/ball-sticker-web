/* Sign Tools — ส่งตัดเข้า Graphtec ผ่าน LAN (Node net, TCP ดิบ) */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var PORTS = [9100, 8000, 4000, 2000, 10001, 23];

  function esc(v) { return JSON.stringify(v).replace(/[\u007f-￿]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); }
  function host(fn, arg) {
    return new Promise(function (resolve) {
      if (!window.__adobe_cep__) return resolve({ error: 'ไม่ได้รันใน Illustrator' });
      window.__adobe_cep__.evalScript(fn + '(' + (arg === undefined ? '' : esc(arg)) + ')', function (r) {
        try { resolve(JSON.parse(r)); } catch (e) { resolve({ error: 'สคริปต์ผิดพลาด: ' + String(r).slice(0, 200) }); }
      });
    });
  }
  function req() { return (window.cep_node && window.cep_node.require) || window.__testRequire || null; }
  var toastT;
  function toast(t) { var el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, 3600); }
  function seg(name) { var b = document.querySelector('.seg[data-name="' + name + '"] .on'); return b ? b.dataset.v : null; }
  function ip() { return ($('cutIp').value || '').replace(/\s+/g, ''); }
  function port() { var p = parseInt($('cutPort').value, 10); return p > 0 && p < 65536 ? p : 0; }
  function validIp(s) { return /^(\d{1,3})(\.\d{1,3}){3}$/.test(s) && s.split('.').every(function (n) { return +n <= 255; }); }
  function status(t, cls) { var s = $('cutStatus'); s.textContent = t; s.className = 'hint ' + (cls || ''); }
  function opts() {
    return { lang: seg('cutLang') || 'gpgl', step: parseFloat($('cutStep').value) || 0.1, rotate: $('cutRot').checked, mirror: $('cutMirror').checked, overcut: Math.max(0, parseFloat($('cutOver').value) || 0) };
  }

  function tryPort(h, p, ms) { return STCut.net(req()).tryPort(h, p, ms); }
  function send(h, p, data) { return STCut.net(req(), window.cep_node && window.cep_node.Buffer).send(h, p, data); }

  // ---------- อ่านงาน ----------
  var job = null;
  function draw() {
    var cv = $('cutCanvas'), g = cv.getContext('2d');
    g.clearRect(0, 0, cv.width, cv.height);
    if (!job) return;
    var pad = 14, sc = Math.min((cv.width - 2 * pad) / Math.max(job.w, 1), (cv.height - 2 * pad) / Math.max(job.h, 1));
    var ox = pad, oy = cv.height - pad;
    g.strokeStyle = 'rgba(255,255,255,.18)'; g.setLineDash([3, 3]); g.strokeRect(ox, oy - job.h * sc, job.w * sc, job.h * sc); g.setLineDash([]);
    g.strokeStyle = '#ff4fa3'; g.lineWidth = 1.2;
    job.polys.forEach(function (pl) {
      g.beginPath();
      pl.forEach(function (q, i) { var x = ox + q[0] * sc, y = oy - q[1] * sc; if (i) g.lineTo(x, y); else g.moveTo(x, y); });
      g.stroke();
    });
    // จุดเริ่ม (origin เครื่อง) + แกน
    g.fillStyle = '#ffd23f'; g.beginPath(); g.arc(ox, oy, 3.5, 0, 7); g.fill();
    g.font = '10px sans-serif'; g.fillText('X+', ox + 22, oy - 4); g.fillText('Y+', ox + 4, oy - 22);
    g.strokeStyle = '#ffd23f'; g.lineWidth = 1; g.beginPath(); g.moveTo(ox, oy); g.lineTo(ox + 18, oy); g.moveTo(ox, oy); g.lineTo(ox, oy - 18); g.stroke();
  }
  var raw = null, rawLabel = '';
  function rebuild() {
    if (!raw) { job = null; draw(); $('cutGo').disabled = true; return; }
    var r = STCut.build(raw, opts());
    if (r.error) { job = null; $('cutRes').textContent = r.error; $('cutGo').disabled = true; draw(); return; }
    job = r;
    $('cutRes').innerHTML = rawLabel + '<small>' + r.n + ' เส้น · ขนาดงาน ' + r.w.toFixed(1) + ' × ' + r.h.toFixed(1) + ' มม. (X × Y) · ' + Math.round(r.data.length / 1024 * 10) / 10 + ' KB</small>';
    $('cutGo').disabled = false;
    draw();
  }
  $('cutRead').onclick = function () {
    $('cutRead').disabled = true;
    host('st_cutRead').then(function (r) {
      $('cutRead').disabled = false;
      if (r.error) { raw = null; $('cutRes').textContent = '⚠ ' + r.error; rebuild(); return; }
      var w = [];
      if (r.text) w.push('มีตัวอักษร ' + r.text + ' ชิ้นที่ยังไม่ได้ Create Outlines — ไม่ได้ส่งตัด');
      if (r.other) w.push('ข้าม ' + r.other + ' ชิ้นที่ไม่ใช่เส้น (รูปภาพ/อื่นๆ)');
      $('cutWarn').textContent = w.join(' · ');
      if (!r.n) {
        raw = null; rebuild();
        $('cutRes').textContent = r.src === 'sel' ? 'ไม่มีเส้นในสิ่งที่เลือก' : 'ไม่พบเส้นสี CutContour ใน artboard นี้ — เลือกเส้นที่จะตัดแล้วกดอ่านใหม่';
        return;
      }
      raw = r.paths; rawLabel = r.src === 'sel' ? 'เส้นที่เลือก' : 'เส้น CutContour ใน artboard';
      rebuild();
    });
  };
  $('cutTest').onclick = function () {
    raw = STCut.testPaths(); rawLabel = 'ชิ้นทดสอบ 20×20 มม.'; $('cutWarn').textContent = '';
    rebuild();
    status('ชิ้นทดสอบ: กรอบ 20 มม. · ลูกศรชี้ทาง X · ขีดสั้นชี้ทาง Y — วัดว่าได้ 20 มม. จริงไหม', '');
  };
  ['cutRot', 'cutMirror', 'cutOver', 'cutStep'].forEach(function (id) { $(id).addEventListener('change', rebuild); });
  document.querySelectorAll('.seg[data-name="cutLang"] button').forEach(function (b) {
    b.addEventListener('click', function () { setTimeout(function () { langUI(); rebuild(); }, 0); });
  });
  function langUI() { document.getElementById('tab-cut').classList.toggle('isGpgl', seg('cutLang') === 'gpgl'); }

  // ---------- ตรวจหาพอร์ต ----------
  $('cutProbe').onclick = function () {
    var h = ip();
    if (!validIp(h)) { status('ใส่ IP ของเครื่องตัดก่อน (ดูที่เครื่อง: MENU › I/F › LAN)', 'warn'); return; }
    if (!req()) { status('ใช้ได้เฉพาะใน Illustrator', 'warn'); return; }
    $('cutProbe').disabled = true; status('กำลังตรวจหาพอร์ตที่ ' + h + ' …', '');
    Promise.all(PORTS.map(function (p) { return tryPort(h, p, 2500).then(function (ok) { return ok ? p : 0; }); })).then(function (list) {
      $('cutProbe').disabled = false;
      var open = list.filter(Boolean);
      if (!open.length) { status('ไม่เจอพอร์ตที่เปิดอยู่ · เช็คว่าเครื่องเปิดอยู่, IP ถูก, อยู่วงแลนเดียวกับ Mac และปิด Cutting Master ก่อน', 'warn'); return; }
      $('cutPort').value = open[0]; $('cutPort').dispatchEvent(new Event('change'));
      status('✓ เจอเครื่อง · พอร์ตที่เปิด: ' + open.join(', ') + ' (ใช้ ' + open[0] + ')', 'ok');
    });
  };

  // ---------- ส่งตัด (กด 2 ครั้งเพื่อยืนยัน) ----------
  var armT = null;
  $('cutGo').onclick = function () {
    if (!job) return;
    var h = ip(), p = port();
    if (!validIp(h) || !p) { status('ตั้ง IP และพอร์ตก่อน (กด "ตรวจหา")', 'warn'); return; }
    if (!req()) { status('ใช้ได้เฉพาะใน Illustrator', 'warn'); return; }
    var b = $('cutGo');
    if (!b.classList.contains('arm')) {
      b.classList.add('arm'); b.textContent = 'กดอีกครั้งเพื่อตัด · ' + job.w.toFixed(0) + '×' + job.h.toFixed(0) + ' มม.';
      clearTimeout(armT); armT = setTimeout(disarm, 4000); return;
    }
    disarm(); b.disabled = true; status('กำลังส่งงานไป ' + h + ':' + p + ' …', '');
    send(h, p, job.data).then(function (n) {
      b.disabled = false;
      status('✓ ส่งแล้ว ' + Math.round(n / 1024 * 10) / 10 + ' KB · ' + job.n + ' เส้น', 'ok'); toast('✓ ส่งงานเข้าเครื่องตัดแล้ว');
    }, function (e) {
      b.disabled = false; status('⚠ ส่งไม่ได้: ' + e.message + ' · ถ้า Cutting Master เปิดค้างอยู่ให้ปิดก่อน', 'warn');
    });
  };
  function disarm() { clearTimeout(armT); var b = $('cutGo'); b.classList.remove('arm'); b.textContent = 'ส่งตัด'; }

  langUI(); draw();
})();
