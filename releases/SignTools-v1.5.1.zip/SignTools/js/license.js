/* Sign Tools — license screen + update banner (browser side) */
(function () {
  'use strict';
  var C = window.ST_CONFIG || {};
  var $ = function (id) { return document.getElementById(id); };
  var lock = $('lic'), msg = $('licMsg'), keyIn = $('licKey'), btn = $('licGo');

  function nodeReq() { return (window.cep_node && window.cep_node.require) || window.__testRequire || null; }
  function osPath(p) { p = decodeURIComponent(p); if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1); return p; }
  function extDir() { return osPath(location.pathname).replace(/[\\/][^\\/]*$/, ''); }

  var core = null;
  try {
    var req = nodeReq();
    var proc = (window.cep_node && window.cep_node.process) || (req && req('process'));
    var env = proc ? proc.env : {};
    var base = env.APPDATA || ((env.HOME || '') + '/Library/Application Support');
    core = req(extDir() + '/js/core.js')({
      extDir: extDir(), dataDir: base + '/SignTools', server: C.server, pubkey: C.pubkey, allowHttp: !!C.allowHttp
    });
  } catch (e) {
    console.error(e);
  }

  function show(on) { lock.classList.toggle('show', on); document.body.classList.toggle('locked', on); }
  function say(t, bad) { msg.textContent = t || ''; msg.className = 'licmsg' + (bad ? ' bad' : ''); }
  var toastT;
  function toast(t) { var el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, 3000); }

  if (!core) {
    show(true);
    say('เปิดระบบไลเซนส์ไม่ได้ — ติดตั้งเวอร์ชันล่าสุดใหม่อีกครั้ง หรือติดต่อ ' + (C.contact || 'ผู้ขาย'), true);
    btn.disabled = true;
    return;
  }

  $('ver').textContent = 'v' + core.version();

  // ---------- เปิดใช้คีย์ ----------
  function doActivate() {
    var k = keyIn.value.trim();
    if (!/^ST-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/i.test(k)) { say('รูปแบบคีย์: ST-XXXX-XXXX-XXXX-XXXX', true); return; }
    btn.disabled = true; say('กำลังตรวจสอบ…');
    core.activate(k).then(function (s) {
      btn.disabled = false; say(''); show(false); keyIn.value = '';
      toast('✓ เปิดใช้งานแล้ว — ขอบคุณที่สนับสนุนครับ');
      afterUnlock(s);
    }, function (e) {
      btn.disabled = false; say(e.message, true);
    });
  }
  btn.onclick = doActivate;
  keyIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') doActivate(); });
  keyIn.addEventListener('input', function () {
    // จัดรูปแบบอัตโนมัติ ST-XXXX-…
    var raw = keyIn.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (raw.indexOf('ST') === 0) raw = raw.slice(2);
    var g = raw.slice(0, 16).match(/.{1,4}/g) || [];
    var v = g.length ? 'ST-' + g.join('-') : keyIn.value.toUpperCase();
    if (v !== keyIn.value) keyIn.value = v;
  });

  // ---------- เมนูไลเซนส์ ----------
  $('licInfoBtn').onclick = function () {
    var s = core.localStatus();
    $('licInfoText').textContent = s.state === 'ok'
      ? 'คีย์ ' + s.masked + ' · เปิดใช้งานบนเครื่องนี้'
      : 'ยังไม่ได้เปิดใช้';
    $('licInfo').classList.toggle('show');
  };
  $('licMove').onclick = function () {
    if (!confirm('ยกเลิกคีย์จากเครื่องนี้ เพื่อนำไปใช้เครื่องอื่น?')) return;
    core.deactivate().then(function () {
      $('licInfo').classList.remove('show'); show(true); say('ยกเลิกจากเครื่องนี้แล้ว — นำคีย์ไปใส่ที่เครื่องใหม่ได้เลย');
    }, function (e) { toast('⚠ ' + e.message + ' (ต้องต่อเน็ต)'); });
  };

  // ---------- อัปเดต ----------
  // เจอเวอร์ชันใหม่ → ถามก่อน: ตกลง = อัปเดต / ไม่ตอนนี้ = แสดงสถานะ "มีอัปเดต" ค้างไว้
  var pending = null, asked = {}, busy = false;
  function setStatus(kind, text) {
    var st = $('updStatus');
    st.className = 'updstat ' + kind;            // ok | new | wait | err
    $('updStatusText').textContent = text;
    $('updBadge').classList.toggle('show', kind === 'new');
  }
  function openAsk() {
    if (!pending) return;
    $('updTitle').textContent = 'พบเวอร์ชันใหม่ v' + pending.version;
    $('updText').textContent = (pending.notes ? pending.notes + '\n' : '') + 'ตอนนี้ใช้ v' + pending.current + ' — อัปเดตเลยไหม?';
    $('updGo').disabled = false; $('updLater').disabled = false;
    $('updGo').classList.remove('hidden'); $('updLater').textContent = 'ไม่ตอนนี้';
    $('upd').classList.add('show');
  }
  function closeAsk() { $('upd').classList.remove('show'); }
  function checkUpdate(manual) {
    if (busy) return;
    busy = true; $('updCheck').disabled = true;
    if (manual) setStatus('wait', 'กำลังเช็คอัปเดต…');
    core.checkUpdate().then(function (r) {
      busy = false; $('updCheck').disabled = false;
      if (r && r.newer) {
        pending = r;
        setStatus('new', 'มีอัปเดต v' + r.version + ' — กดเพื่ออัปเดต');
        if (manual || !asked[r.version]) { asked[r.version] = 1; if (!$('upd').classList.contains('show')) openAsk(); }
      } else {
        pending = null;
        setStatus('ok', 'v' + core.version() + ' · ใช้เวอร์ชันล่าสุดแล้ว');
        if (manual) toast('✓ ใช้เวอร์ชันล่าสุดแล้ว (v' + core.version() + ')');
      }
    }, function (e) {
      busy = false; $('updCheck').disabled = false;
      if (pending) return;                         // เคยเจออัปเดตแล้ว คงสถานะเดิมไว้
      setStatus('err', 'เช็คอัปเดตไม่ได้ — ' + (e.offline ? 'ไม่ได้ต่อเน็ต' : e.message));
      if (manual) toast('⚠ เช็คอัปเดตไม่ได้: ' + e.message);
    });
  }
  $('updCheck').onclick = function () { lastCheck = Date.now(); checkUpdate(true); };
  $('updStatus').onclick = function () { if (pending) openAsk(); else $('updCheck').click(); };
  $('updBadge').onclick = openAsk;
  $('updLater').onclick = function () {
    closeAsk();
    if (pending) setStatus('new', 'มีอัปเดต v' + pending.version + ' — กดเพื่ออัปเดต');
  };
  $('updGo').onclick = function () {
    if (!pending) return;
    var go = $('updGo'); go.disabled = true; $('updLater').disabled = true;
    core.applyUpdate(pending, function (t) { $('updText').textContent = t; }).then(function (res) {
      if (res.restart) {
        $('updTitle').textContent = '✓ อัปเดตเป็น v' + res.version + ' แล้ว';
        $('updText').textContent = 'ปิดแล้วเปิด Illustrator ใหม่ 1 ครั้ง เพื่อใช้เวอร์ชันใหม่';
        go.classList.add('hidden'); $('updLater').disabled = false; $('updLater').textContent = 'ปิด';
        pending = null; setStatus('wait', 'อัปเดตแล้ว — รอเปิด Illustrator ใหม่');
        return;
      }
      $('updText').textContent = '✓ อัปเดตแล้ว กำลังโหลดใหม่…';
      var jsx = (extDir() + '/jsx/host.jsx').replace(/\\/g, '/');
      if (window.__adobe_cep__) window.__adobe_cep__.evalScript('$.evalFile(new File(' + JSON.stringify(jsx) + '))', function () { location.reload(); });
      else location.reload();
    }, function (e) {
      $('updText').textContent = '⚠ ' + e.message + ' — ลองใหม่ได้';
      go.disabled = false; $('updLater').disabled = false;
    });
  };

  // เช็คตอนเปิดแผง + ทุก 30 นาที + ตอนกลับมาที่แผง (ถ้าไม่ได้เช็คเกิน 10 นาที)
  var lastCheck = 0, timer = null;
  function maybeCheck(minGap) { if (Date.now() - lastCheck >= minGap) { lastCheck = Date.now(); checkUpdate(false); } }
  function afterUnlock() {
    setTimeout(function () { maybeCheck(0); }, 1500);
    if (!timer) {
      timer = setInterval(function () { maybeCheck(0); }, 30 * 60 * 1000);
      window.addEventListener('focus', function () { maybeCheck(10 * 60 * 1000); });
      document.addEventListener('visibilitychange', function () { if (!document.hidden) maybeCheck(10 * 60 * 1000); });
    }
  }

  // ---------- เริ่ม ----------
  var s = core.localStatus();
  if (s.state === 'ok') {
    show(false); afterUnlock(s);
    core.refresh().catch(function (e) {
      if (e.code) { show(true); say(e.message, true); }   // ถูกระงับ / ย้ายเครื่อง
    });
  } else {
    show(true);
    if (s.state === 'expired') {
      say('กำลังยืนยันไลเซนส์ออนไลน์…');
      core.refresh().then(function (s2) { show(false); say(''); afterUnlock(s2); },
        function (e) { say(e.offline ? (s.clock ? 'เวลาในเครื่องไม่ถูกต้อง — ตั้งวันเวลาให้ตรง แล้วต่อเน็ตเพื่อยืนยันไลเซนส์' : 'ต้องต่อเน็ตเพื่อยืนยันไลเซนส์ — ต่อเน็ตแล้วเปิดแผงใหม่') : e.message, true); });
    } else if (s.state === 'invalid') say('ไลเซนส์ในเครื่องไม่ตรงกับเครื่องนี้ — ใส่คีย์อีกครั้ง', true);
    setTimeout(function () { keyIn.focus(); }, 100);
  }
})();
