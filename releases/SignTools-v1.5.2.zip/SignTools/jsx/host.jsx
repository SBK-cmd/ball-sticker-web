// Sign Tools — ExtendScript (Illustrator side). ES3 only: no forEach/map/indexOf on arrays, no JSON, no trim.
var MM = 72 / 25.4;

function st_q(s) {
    s = String(s);
    var o = '"';
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i), k = s.charCodeAt(i);
        if (c === '"') o += '\\"';
        else if (c === '\\') o += '\\\\';
        else if (k < 32 || k > 126) { var h = k.toString(16); while (h.length < 4) h = '0' + h; o += '\\u' + h; }
        else o += c;
    }
    return o + '"';
}
function st_ok(msg) { return '{"ok":true,"msg":' + st_q(msg) + '}'; }
function st_err(msg) { return '{"error":' + st_q(msg) + '}'; }

function st_doc() {
    if (app.documents.length === 0) throw new Error('ยังไม่มีเอกสารเปิดอยู่');
    return app.activeDocument;
}
function st_writableLayer(doc) {
    var L = doc.activeLayer;
    if (L.locked || !L.visible) throw new Error('เลเยอร์ที่ใช้งานอยู่ถูกล็อกหรือซ่อนอยู่');
    return L;
}

// สีจากค่า RGB 0-255 (แปลงเป็น CMYK อัตโนมัติถ้าเอกสารเป็น CMYK)
function st_color(doc, rgb, cmyk) {
    var c;
    if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
        c = new CMYKColor(); c.cyan = cmyk[0]; c.magenta = cmyk[1]; c.yellow = cmyk[2]; c.black = cmyk[3];
    } else {
        c = new RGBColor(); c.red = rgb[0]; c.green = rgb[1]; c.blue = rgb[2];
    }
    return c;
}

function st_unionBounds(items) {
    var b = null;
    for (var i = 0; i < items.length; i++) {
        var g = items[i].geometricBounds;
        if (!b) b = [g[0], g[1], g[2], g[3]];
        else { b[0] = Math.min(b[0], g[0]); b[1] = Math.max(b[1], g[1]); b[2] = Math.max(b[2], g[2]); b[3] = Math.min(b[3], g[3]); }
    }
    return b;
}

// artboard ที่มีจุดกึ่งกลางของ bounds อยู่ข้างใน
function st_artboardOf(doc, b) {
    var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    for (var i = 0; i < doc.artboards.length; i++) {
        var r = doc.artboards[i].artboardRect;
        if (cx >= r[0] && cx <= r[2] && cy <= r[1] && cy >= r[3]) return i;
    }
    return doc.artboards.getActiveArtboardIndex();
}

function st_selection(doc) {
    var sel = doc.selection, out = [];
    if (!sel || typeof sel.length === 'undefined') return out;
    for (var i = 0; i < sel.length; i++) out.push(sel[i]);
    return out;
}

function st_collectText(items, out) {
    for (var i = 0; i < items.length; i++) {
        var it = items[i];
        if (it.typename === 'TextFrame') out.push(it);
        else if (it.typename === 'GroupItem') {
            var kids = [];
            for (var j = 0; j < it.pageItems.length; j++) kids.push(it.pageItems[j]);
            st_collectText(kids, out);
        }
    }
    return out;
}

function st_pad(n, digits) {
    var neg = n < 0, s = String(Math.abs(n));
    while (s.length < digits) s = '0' + s;
    return (neg ? '-' : '') + s;
}

function st_sortItems(arr, order) {
    // คำนวณค่าอ้างอิงตำแหน่งครั้งเดียว
    var a = [];
    for (var i = 0; i < arr.length; i++) {
        var g = arr[i].geometricBounds;
        a.push({ it: arr[i], x: (g[0] + g[2]) / 2, y: (g[1] + g[3]) / 2, h: Math.abs(g[1] - g[3]), w: Math.abs(g[2] - g[0]) });
    }
    var tol = 0;
    for (var k = 0; k < a.length; k++) tol += (order === 'tb' ? a[k].w : a[k].h);
    tol = a.length ? tol / a.length / 2 : 0;
    a.sort(function (p, q) {
        if (order === 'tb') {                       // คอลัมน์ซ้าย→ขวา แต่ละคอลัมน์บน→ล่าง
            if (Math.abs(p.x - q.x) > tol) return p.x - q.x;
            return q.y - p.y;
        }
        if (Math.abs(p.y - q.y) > tol) return q.y - p.y; // แถวบน→ล่าง แต่ละแถวซ้าย→ขวา
        return p.x - q.x;
    });
    var out = [];
    for (var m = 0; m < a.length; m++) out.push(a[m].it);
    return out;
}

// ---------------- 1) รันเลข ----------------
function st_runNumber(o) {
    try {
        var doc = st_doc(), sel = st_selection(doc);
        var frames = st_collectText(sel, []);
        if (!frames.length) return st_err('เลือกกล่องข้อความก่อน');
        var fmt = function (k) { return o.prefix + st_pad(o.start + k * o.step, o.digits) + o.suffix; };

        if (o.mode === 'ab') {
            if (frames.length !== 1) return st_err('โหมดทุก artboard: เลือกกล่องข้อความต้นแบบ 1 กล่อง');
            var tpl = frames[0], src = st_artboardOf(doc, tpl.geometricBounds);
            var sr = doc.artboards[src].artboardRect, n = 0;
            for (var i = 0; i < o.range.length; i++) {
                var t = o.range[i];
                if (t < 0 || t >= doc.artboards.length) continue;
                var tf = tpl;
                if (t !== src) {
                    var r = doc.artboards[t].artboardRect;
                    tf = tpl.duplicate();
                    tf.translate(r[0] - sr[0], r[1] - sr[1]);
                }
                tf.contents = fmt(n);
                n++;
            }
            return st_ok('ใส่เลข ' + n + ' artboard แล้ว (' + fmt(0) + ' – ' + fmt(n - 1) + ')');
        }

        var list = (o.order === 'sel') ? frames : st_sortItems(frames, o.order);
        for (var j = 0; j < list.length; j++) list[j].contents = fmt(j);
        return st_ok('ใส่เลข ' + list.length + ' กล่องแล้ว (' + fmt(0) + ' – ' + fmt(list.length - 1) + ')');
    } catch (e) { return st_err(e.message); }
}

// ---------------- 2) ก็อปไปทุก artboard ----------------
function st_duplicate(o) {
    try {
        var doc = st_doc(), sel = st_selection(doc);
        if (!sel.length) return st_err('เลือกวัตถุที่จะก็อปก่อน');
        var src = st_artboardOf(doc, st_unionBounds(sel));
        var sr = doc.artboards[src].artboardRect, n = 0;
        for (var i = 0; i < o.range.length; i++) {
            var t = o.range[i];
            if (t === src || t < 0 || t >= doc.artboards.length) continue;
            var r = doc.artboards[t].artboardRect;
            for (var j = 0; j < sel.length; j++) {
                var d = sel[j].duplicate();
                d.translate(r[0] - sr[0], r[1] - sr[1]);
            }
            n++;
        }
        return st_ok('ก็อปไป ' + n + ' artboard แล้ว (ต้นฉบับอยู่ artboard ' + (src + 1) + ')');
    } catch (e) { return st_err(e.message); }
}

// ---------------- 3) QR Code ----------------
// o.rows = ["0101..", ...] (ไม่รวมขอบ), o.sizeMM = ขนาดรวมขอบ, o.quiet = จำนวนช่องขอบ, o.bg = ใส่พื้นขาว
function st_qr(o) {
    try {
        var doc = st_doc(), layer = st_writableLayer(doc);
        var n = o.rows.length, total = n + o.quiet * 2;
        var size = o.sizeMM * MM, m = size / total;
        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
        var left = (ab[0] + ab[2]) / 2 - size / 2, top = (ab[1] + ab[3]) / 2 + size / 2;

        var grp = layer.groupItems.add();
        grp.name = 'QR Code';
        if (o.bg) {
            var bg = grp.pathItems.rectangle(top, left, size, size);
            bg.stroked = false; bg.filled = true;
            bg.fillColor = st_color(doc, [255, 255, 255], [0, 0, 0, 0]);
            bg.name = 'QR background';
        }
        var ink = st_color(doc, [0, 0, 0], [0, 0, 0, 100]);
        var cp = grp.compoundPathItems.add();
        cp.name = 'QR modules';
        for (var r = 0; r < n; r++) {
            var row = o.rows[r], c = 0;
            while (c < n) {
                if (row.charAt(c) === '1') {
                    var s = c;
                    while (c < n && row.charAt(c) === '1') c++;
                    // ขยายเล็กน้อยกันเส้นขาวระหว่างช่องเวลา render
                    var p = cp.pathItems.rectangle(top - (r + o.quiet) * m, left + (s + o.quiet) * m, (c - s) * m, m + 0.01);
                    p.stroked = false; p.filled = true; p.fillColor = ink;
                } else c++;
            }
        }
        grp.selected = true;
        return st_ok('วาง QR ' + o.sizeMM + ' มม. (' + n + '×' + n + ' ช่อง) กลาง artboard แล้ว');
    } catch (e) { return st_err(e.message); }
}

// ---------------- 4) เส้นบอกขนาด ----------------
function st_fmtLen(pt, o) {
    var f = { 'mm': 25.4 / 72, 'cm': 2.54 / 72, 'in': 1 / 72 }[o.unit];
    var v = pt * f * o.scale, p = Math.pow(10, o.decimals);
    var s = (Math.round(v * p) / p).toFixed(o.decimals);
    return s + (o.showUnit ? ' ' + o.unit : '');
}

function st_line(grp, pts, col, w) {
    var p = grp.pathItems.add();
    p.setEntirePath(pts);
    p.filled = false; p.stroked = true; p.strokeColor = col; p.strokeWidth = w;
    return p;
}
function st_tri(grp, pts, col) {
    var p = grp.pathItems.add();
    p.setEntirePath(pts); p.closed = true;
    p.stroked = false; p.filled = true; p.fillColor = col;
    return p;
}
function st_label(grp, txt, o, col) {
    var t = grp.textFrames.add();
    t.contents = txt;
    t.textRange.characterAttributes.size = o.textPt;
    t.textRange.characterAttributes.fillColor = col;
    return t;
}

function st_dimOne(doc, layer, b, o, col) {
    var g = layer.groupItems.add();
    g.name = 'Dimension';
    var off = o.offsetMM * MM, gap = 1 * MM, ext = 1.5 * MM, a = Math.max(1.2, o.lineW * 6), lw = o.lineW;
    var L = b[0], T = b[1], R = b[2], B = b[3];

    if (o.which !== 'h') { // ความกว้าง — เหนือวัตถุ
        var y = T + off;
        st_line(g, [[L, T + gap], [L, y + ext]], col, lw);
        st_line(g, [[R, T + gap], [R, y + ext]], col, lw);
        st_line(g, [[L, y], [R, y]], col, lw);
        st_tri(g, [[L, y], [L + a, y + a / 3], [L + a, y - a / 3]], col);
        st_tri(g, [[R, y], [R - a, y + a / 3], [R - a, y - a / 3]], col);
        var tw = st_label(g, st_fmtLen(R - L, o), o, col);
        tw.left = (L + R) / 2 - tw.width / 2;
        tw.top = y + gap + tw.height;
    }
    if (o.which !== 'w') { // ความสูง — ขวาของวัตถุ
        var x = R + off;
        st_line(g, [[R + gap, T], [x + ext, T]], col, lw);
        st_line(g, [[R + gap, B], [x + ext, B]], col, lw);
        st_line(g, [[x, T], [x, B]], col, lw);
        st_tri(g, [[x, T], [x - a / 3, T - a], [x + a / 3, T - a]], col);
        st_tri(g, [[x, B], [x - a / 3, B + a], [x + a / 3, B + a]], col);
        var th = st_label(g, st_fmtLen(T - B, o), o, col);
        th.rotate(90);
        th.left = x + gap;
        th.top = (T + B) / 2 + th.height / 2;
    }
    return g;
}

function st_dimension(o) {
    try {
        var doc = st_doc(), layer = st_writableLayer(doc), sel = st_selection(doc);
        if (!sel.length) return st_err('เลือกวัตถุที่จะวัดก่อน');
        var col = null, made = [];
        if (o.swatch) { try { col = doc.swatches.getByName(o.swatch).color; } catch (e1) { col = null; } }
        if (!col) col = st_color(doc, o.rgb, o.cmyk);
        if (o.each) for (var i = 0; i < sel.length; i++) made.push(st_dimOne(doc, layer, sel[i].geometricBounds, o, col));
        else made.push(st_dimOne(doc, layer, st_unionBounds(sel), o, col));
        return st_ok('ใส่เส้นบอกขนาด ' + made.length + ' ชุดแล้ว');
    } catch (e) { return st_err(e.message); }
}

function st_info() {
    try {
        if (app.documents.length === 0) return '{"artboards":0}';
        var d = app.activeDocument;
        return '{"artboards":' + d.artboards.length + ',"active":' + d.artboards.getActiveArtboardIndex() + '}';
    } catch (e) { return st_err(e.message); }
}
// Thai Font Preview — ExtendScript (Illustrator side)
function tfp_q(s) {
    s = String(s);
    var o = '"';
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i), k = s.charCodeAt(i);
        if (c === '"') o += '\\"';
        else if (c === '\\') o += '\\\\';
        else if (k < 32 || k > 126) { var h = k.toString(16); while (h.length < 4) h = '0' + h; o += '\\u' + h; }
        else o += c;
    }
    return o + '"';
}
function tfp_err(msg) { return '{"error":' + tfp_q(msg) + '}'; }
function tfp_ok(msg) { return '{"ok":true,"msg":' + tfp_q(msg) + '}'; }

// ---------- ฟอนต์ที่ติดตั้ง ----------
function tfp_listFonts() {
    try {
        var f = app.textFonts, out = [];
        for (var i = 0; i < f.length; i++) {
            try {
                var t = f[i];
                out.push('{"n":' + tfp_q(t.name) + ',"f":' + tfp_q(t.family) + ',"s":' + tfp_q(t.style) + '}');
            } catch (e) {}
        }
        return '{"fonts":[' + out.join(',') + ']}';
    } catch (e) { return tfp_err(e.message); }
}

// หา TextFrame ทั้งหมดในสิ่งที่เลือก (รวมในกลุ่ม / clipping group)
function tfp_collect(item, out) {
    if (!item) return;
    var t = item.typename;
    if (t === 'TextFrame') { if (!item.locked) out.push(item); }
    else if (t === 'GroupItem') {
        for (var i = 0; i < item.pageItems.length; i++) tfp_collect(item.pageItems[i], out);
    }
}
function tfp_font(name) {
    try { return app.textFonts.getByName(name); } catch (e) {}
    for (var i = 0; i < app.textFonts.length; i++) if (app.textFonts[i].name === name) return app.textFonts[i];
    throw new Error('ไม่พบฟอนต์ ' + name);
}

// กดฟอนต์ = เปลี่ยนฟอนต์ของข้อความที่เลือกทันที
//  - ลากคลุมตัวอักษรอยู่ (Type tool) → เปลี่ยนเฉพาะตัวที่คลุม
//  - เลือกกล่องข้อความ / กลุ่ม → เปลี่ยนทั้งกล่อง
//  - ไม่ได้เลือกอะไร → วางข้อความตัวอย่างใหม่
function tfp_applyFont(fontName, sample, size) {
    try {
        if (app.documents.length === 0) return tfp_err('ยังไม่มีเอกสารเปิดอยู่');
        var doc = app.activeDocument, font = tfp_font(fontName), sel = doc.selection;

        if (sel && sel.typename === 'TextRange') {
            if (sel.length === 0) {
                // แค่วางเคอร์เซอร์ → ใช้กับทั้งกล่องนั้น
                sel.story.textRange.characterAttributes.textFont = font;
                return tfp_ok('เปลี่ยนเป็น ' + font.family + ' ' + font.style);
            }
            sel.characterAttributes.textFont = font;
            return tfp_ok('เปลี่ยน ' + sel.length + ' ตัวอักษรเป็น ' + font.family + ' ' + font.style);
        }

        var frames = [], hasSel = sel && sel.length > 0;
        if (hasSel) for (var i = 0; i < sel.length; i++) tfp_collect(sel[i], frames);
        if (frames.length) {
            for (var j = 0; j < frames.length; j++) frames[j].textRange.characterAttributes.textFont = font;
            return tfp_ok('เปลี่ยน ' + frames.length + ' กล่องเป็น ' + font.family + ' ' + font.style);
        }
        if (hasSel) return tfp_err('ที่เลือกไว้ไม่มีข้อความ (อาจถูก Create Outlines หรือล็อกอยู่)');

        var ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
        var tf = doc.textFrames.add();
        tf.contents = sample;
        tf.textRange.characterAttributes.textFont = font;
        tf.textRange.characterAttributes.size = size;
        tf.left = ab[0] + 20;
        tf.top = ab[1] - 20;
        tf.selected = true;
        return tfp_ok('วางข้อความตัวอย่างแล้ว (เลือกไว้ กดฟอนต์อื่นต่อได้เลย)');
    } catch (e) { return tfp_err(e.message); }
}

// ฟอนต์ของข้อความที่เลือกตอนนี้ (ไว้ไฮไลต์ในรายการ)
function tfp_currentFont() {
    try {
        if (app.documents.length === 0) return '{"font":null}';
        var sel = app.activeDocument.selection, tr = null;
        if (sel && sel.typename === 'TextRange') tr = sel.length ? sel : sel.story.textRange;
        else if (sel && sel.length) { var f = []; for (var i = 0; i < sel.length && !f.length; i++) tfp_collect(sel[i], f); if (f.length) tr = f[0].textRange; }
        if (!tr || !tr.characters.length) return '{"font":null}';
        return '{"font":' + tfp_q(tr.characters[0].characterAttributes.textFont.name) + '}';
    } catch (e) { return '{"font":null}'; }
}

// ---------- ตัวที่วาดเอง (artboard ละ 1 ตัว) ----------
function tfp_exportGlyphs() {
    try {
        if (app.documents.length === 0) return tfp_err('ยังไม่มีเอกสารเปิดอยู่');
        var doc = app.activeDocument, abs = doc.artboards;
        var key = String(doc.name).replace(/[^A-Za-z0-9_-]/g, '_');
        var folder = new Folder(Folder.temp + '/tfp_glyphs_' + key);
        if (!folder.exists) folder.create();
        var old = folder.getFiles('*.png');
        for (var d = 0; d < old.length; d++) { try { old[d].remove(); } catch (e) {} }

        var maxH = 1;
        for (var i = 0; i < abs.length; i++) {
            var r = abs[i].artboardRect, h = r[1] - r[3];
            if (h > maxH) maxH = h;
        }
        var scale = Math.min(800, Math.max(20, 220 / maxH * 100));
        var opts = new ExportOptionsPNG24();
        opts.antiAliasing = true;
        opts.transparency = true;
        opts.artBoardClipping = true;
        opts.horizontalScale = scale;
        opts.verticalScale = scale;

        var orig = abs.getActiveArtboardIndex(), out = [];
        for (var j = 0; j < abs.length; j++) {
            abs.setActiveArtboardIndex(j);
            var rr = abs[j].artboardRect;
            var file = new File(folder.fsName + '/g' + j + '.png');
            doc.exportFile(file, ExportType.PNG24, opts);
            out.push('{"i":' + j + ',"name":' + tfp_q(abs[j].name) + ',"w":' + (rr[2] - rr[0]) +
                     ',"h":' + (rr[1] - rr[3]) + ',"path":' + tfp_q(file.fsName) + '}');
        }
        abs.setActiveArtboardIndex(orig);
        return '{"doc":' + tfp_q(doc.name) + ',"glyphs":[' + out.join(',') + ']}';
    } catch (e) { return tfp_err(e.message); }
}

// ---------- สวอตช์ของเอกสาร (สำหรับเลือกสีเส้นบอกขนาด) ----------
function st_hex2(n) { n = Math.max(0, Math.min(255, Math.round(n))); var h = n.toString(16); return h.length < 2 ? '0' + h : h; }
function st_colorHex(c) {
    var t = c.typename;
    if (t === 'RGBColor') return '#' + st_hex2(c.red) + st_hex2(c.green) + st_hex2(c.blue);
    if (t === 'CMYKColor') { var k = 1 - c.black / 100;
        return '#' + st_hex2(255 * (1 - c.cyan / 100) * k) + st_hex2(255 * (1 - c.magenta / 100) * k) + st_hex2(255 * (1 - c.yellow / 100) * k); }
    if (t === 'GrayColor') { var g = 255 * (1 - c.gray / 100); return '#' + st_hex2(g) + st_hex2(g) + st_hex2(g); }
    if (t === 'SpotColor') return st_colorHex(c.spot.color);
    return null;   // gradient / pattern / none
}
function st_swatches() {
    try {
        if (app.documents.length === 0) return '{"swatches":[],"doc":null}';
        var doc = app.activeDocument, sw = doc.swatches, out = [];
        for (var i = 0; i < sw.length && out.length < 300; i++) {
            try {
                var s = sw[i], nm = s.name;
                if (nm.charAt(0) === '[') continue;            // [None], [Registration]
                var hx = st_colorHex(s.color);
                if (!hx) continue;
                out.push('{"n":' + st_q(nm) + ',"h":"' + hx + '","spot":' + (s.color.typename === 'SpotColor' ? 'true' : 'false') + '}');
            } catch (e) {}
        }
        return '{"doc":' + st_q(doc.name) + ',"swatches":[' + out.join(',') + ']}';
    } catch (e) { return st_err(e.message); }
}
