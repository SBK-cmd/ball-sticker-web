/* Sign Tools — ส่งตัดเข้า Graphtec ผ่าน LAN (Node net, TCP ดิบ) */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var PORTS = [9100, 8000, 4000, 2000, 10001, 23];

  function esc(v) { return JSON.stringify(v).replace(/[\u007f-￿]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); }
  function host(fn, arg) {
    return new Promise(function (resolve) {
      if (!window.__adobe_cep__) return resolve({ error: 'ไม่ได้รันใน Illustrator' });
      window.__adobe_cep__.evalScript(fn + '(' + (arg === undefined ? '' : esc(arg)) + ')', function (r) {
        try { resolve(JSON.parse(r)); } catch (e) { resolve({ error: 'สคริปต์ผิดพลาด: ' + String(r).slice(0, 200) }); }
      });
    });
  }
  function req() { return (window.cep_node && window.cep_node.require) || window.__testRequire || null; }
  var toastT;
  function toast(t) { var el = $('toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, 3600); }
  function seg(name) { var b = document.querySelector('.seg[data-name="' + name + '"] .on'); return b ? b.dataset.v : null; }
  function ip() { return ($('cutIp').value || '').replace(/\s+/g, ''); }
  function port() { var p = parseInt($('cutPort').value, 10); return p > 0 && p < 65536 ? p : 0; }
  function validIp(s) { return /^(\d{1,3})(\.\d{1,3}){3}$/.test(s) && s.split('.').every(function (n) { return +n <= 255; }); }
  function status(t, cls) { var s = $('cutStatus'); s.textContent = t; s.className = 'hint ' + (cls || ''); }
  function opts() {
    var mk = marks && $('cutUseMk').checked ? { ox: marks.ox, oy: marks.oy, dx: marks.dx, dy: marks.dy, lenMM: marks.lenMM, cond: parseInt($('cutCond').value, 10) || 2 } : null;
    return { lang: seg('cutLang') || 'gpgl', step: parseFloat($('cutStep').value) || 0.1, rotate: $('cutRot').checked, mirror: $('cutMirror').checked, overcut: Math.max(0, parseFloat($('cutOver').value) || 0), marks: mk };
  }

  function tryPort(h, p, ms) { return STCut.net(req()).tryPort(h, p, ms); }
  function send(h, p, data) { return STCut.net(req(), window.cep_node && window.cep_node.Buffer).send(h, p, data); }

  // ---------- อ่านงาน ----------
  var job = null;
  function draw() {
    var cv = $('cutCanvas'), g = cv.getContext('2d');
    g.clearRect(0, 0, cv.width, cv.height);
    if (!job) return;
    var pad = 14, sc = Math.min((cv.width - 2 * pad) / Math.max(job.w, 1), (cv.height - 2 * pad) / Math.max(job.h, 1));
    var ox = pad, oy = cv.height - pad;
    g.strokeStyle = 'rgba(255,255,255,.18)'; g.setLineDash([3, 3]); g.strokeRect(ox, oy - job.h * sc, job.w * sc, job.h * sc); g.setLineDash([]);
    g.strokeStyle = '#ff4fa3'; g.lineWidth = 1.2;
    job.polys.forEach(function (pl) {
      g.beginPath();
      pl.forEach(function (q, i) { var x = ox + q[0] * sc, y = oy - q[1] * sc; if (i) g.lineTo(x, y); else g.moveTo(x, y); });
      g.stroke();
    });
    // จุดเริ่ม (origin เครื่อง) + แกน
    g.fillStyle = '#ffd23f'; g.beginPath(); g.arc(ox, oy, 3.5, 0, 7); g.fill();
    g.font = '10px sans-serif'; g.fillText('X+', ox + 22, oy - 4); g.fillText('Y+', ox + 4, oy - 22);
    g.strokeStyle = '#ffd23f'; g.lineWidth = 1; g.beginPath(); g.moveTo(ox, oy); g.lineTo(ox + 18, oy); g.moveTo(ox, oy); g.lineTo(ox, oy - 18); g.stroke();
  }
  var raw = null, rawLabel = '', marks = null;
  function rebuild() {
    if (!raw) { job = null; draw(); $('cutGo').disabled = true; return; }
    var r = STCut.build(raw, opts());
    if (r.error) { job = null; $('cutRes').textContent = r.error; $('cutGo').disabled = true; draw(); return; }
    job = r;
    $('cutRes').innerHTML = rawLabel + '<small>' + r.n + ' เส้น · ขนาดงาน ' + r.w.toFixed(1) + ' × ' + r.h.toFixed(1) + ' มม. (X × Y) · ' + Math.round(r.data.length / 1024 * 10) / 10 + ' KB</small>';
    $('cutGo').disabled = false;
    draw();
  }
  $('cutRead').onclick = function () {
    $('cutRead').disabled = true;
    host('st_cutRead').then(function (r) {
      $('cutRead').disabled = false;
      if (r.error) { raw = null; $('cutRes').textContent = '⚠ ' + r.error; rebuild(); return; }
      var w = [];
      if (r.text) w.push('มีตัวอักษร ' + r.text + ' ชิ้นที่ยังไม่ได้ Create Outlines — ไม่ได้ส่งตัด');
      if (r.other) w.push('ข้าม ' + r.other + ' ชิ้นที่ไม่ใช่เส้น (รูปภาพ/อื่นๆ)');
      $('cutWarn').textContent = w.join(' · ');
      if (!r.n) {
        raw = null; rebuild();
        $('cutRes').textContent = r.src === 'sel' ? 'ไม่มีเส้นในสิ่งที่เลือก' : 'ไม่พบเส้นสี CutContour ใน artboard นี้ — เลือกเส้นที่จะตัดแล้วกดอ่านใหม่';
        return;
      }
      raw = r.paths; rawLabel = r.src === 'sel' ? 'เส้นที่เลือก' : 'เส้น CutContour ใน artboard';
      marks = r.marks || null;
      if (marks && marks.style !== 1) { w.push('มาร์คแบบ Segment ยังส่งตัดจากแผงไม่ได้ — ใช้ Cutting Master ไปก่อน'); marks = null; }
      $('cutMkRow').classList.toggle('hidden', !marks);
      if (marks) $('cutMkInfo').textContent = 'พบมาร์ค 4 Points · ห่างกัน ' + (marks.dy / 10).toFixed(1) + ' × ' + (marks.dx / 10).toFixed(1) + ' ซม. · เครื่องจะสแกนมาร์คก่อนตัด';
      $('cutWarn').textContent = w.join(' · ');
      rebuild();
    });
  };
  $('cutTest').onclick = function () {
    marks = null; $('cutMkRow').classList.add('hidden');
    raw = STCut.testPaths(); rawLabel = 'ชิ้นทดสอบ 20×20 มม.'; $('cutWarn').textContent = '';
    rebuild();
    status('ชิ้นทดสอบ: กรอบ 20 มม. · ลูกศรชี้ทาง X · ขีดสั้นชี้ทาง Y — วัดว่าได้ 20 มม. จริงไหม', '');
  };
  ['cutRot', 'cutMirror', 'cutOver', 'cutStep', 'cutUseMk', 'cutCond'].forEach(function (id) { $(id).addEventListener('change', rebuild); });
  document.querySelectorAll('.seg[data-name="cutLang"] button').forEach(function (b) {
    b.addEventListener('click', function () { setTimeout(function () { langUI(); rebuild(); }, 0); });
  });
  function langUI() { document.getElementById('tab-cut').classList.toggle('isGpgl', seg('cutLang') === 'gpgl'); }

  // ---------- ตรวจหาพอร์ต ----------
  $('cutProbe').onclick = function () {
    var h = ip();
    if (!validIp(h)) { status('ใส่ IP ของเครื่องตัดก่อน (ดูที่เครื่อง: MENU › I/F › LAN)', 'warn'); return; }
    if (!req()) { status('ใช้ได้เฉพาะใน Illustrator', 'warn'); return; }
    $('cutProbe').disabled = true; status('กำลังตรวจหาพอร์ตที่ ' + h + ' …', '');
    Promise.all(PORTS.map(function (p) { return tryPort(h, p, 2500).then(function (ok) { return ok ? p : 0; }); })).then(function (list) {
      $('cutProbe').disabled = false;
      var open = list.filter(Boolean);
      if (!open.length) { status('ไม่เจอพอร์ตที่เปิดอยู่ · เช็คว่าเครื่องเปิดอยู่, IP ถูก, อยู่วงแลนเดียวกับ Mac และปิด Cutting Master ก่อน', 'warn'); return; }
      $('cutPort').value = open[0]; $('cutPort').dispatchEvent(new Event('change'));
      status('✓ เจอเครื่อง · พอร์ตที่เปิด: ' + open.join(', ') + ' (ใช้ ' + open[0] + ')', 'ok');
    });
  };

  // ---------- ส่งตัด (กด 2 ครั้งเพื่อยืนยัน) ----------
  var armT = null;

  // ======== ดักคำสั่ง CM5: proxy 127.0.0.1:capPort ↔ เครื่องตัด ip:port · จดทั้งสองทาง ========
  var cap = null;
  function capStop(msg) {
    if (!cap) return;
    try { cap.srv.close(); } catch (e) {}
    cap.socks.forEach(function (s) { try { s.destroy(); } catch (e) {} });
    try { cap.fs.closeSync(cap.fd); } catch (e) {}
    $('capGo').textContent = 'เริ่มดัก'; $('capMsg').textContent = (msg || 'หยุดดักแล้ว') + ' · ไฟล์: ' + cap.file;
    cap = null;
  }
  $('capGo').onclick = function () {
    if (cap) return capStop();
    var R = req(); if (!R) return toast('⚠ ต้องรันใน Illustrator');
    var h = ip(), p = port(), lp = parseInt($('capPort').value, 10) || 9100;
    if (!validIp(h) || !p) return toast('⚠ ใส่ IP และพอร์ตของเครื่องตัดด้านบนก่อน (กดตรวจหา)');
    var net = R('net'), fs = R('fs'), path = R('path'), env = (window.cep_node && window.cep_node.process ? window.cep_node.process : R('process')).env;
    var dir = path.join(env.USERPROFILE || env.HOME || '.', 'Desktop', 'SignTools-capture');
    try { if (!fs.existsSync(dir)) fs.mkdirSync(dir); } catch (e) {}
    var d = new Date(), stamp = d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2) + '-' + ('0' + d.getHours()).slice(-2) + ('0' + d.getMinutes()).slice(-2) + ('0' + d.getSeconds()).slice(-2);
    var file = path.join(dir, 'cm5-' + stamp + '.jsonl'), fd = fs.openSync(file, 'w'), t0 = Date.now(), nIn = 0, nOut = 0, conns = 0;
    function log(dir2, buf) { try { fs.writeSync(fd, JSON.stringify({ t: Date.now() - t0, d: dir2, b: buf.toString('base64') }) + '\n'); } catch (e) {} }
    function upd() { $('capMsg').textContent = 'กำลังดัก · การเชื่อมต่อ ' + conns + ' · CM5→เครื่อง ' + nOut + ' ไบต์ · เครื่อง→CM5 ' + nIn + ' ไบต์ · ' + file; }
    var srv = net.createServer(function (c) {
      conns++; log('open', Buffer.from(''));
      var up = net.connect(p, h); cap && cap.socks.push(c, up);
      c.on('data', function (b) { nOut += b.length; log('>', b); up.write(b); upd(); });
      up.on('data', function (b) { nIn += b.length; log('<', b); c.write(b); upd(); });
      c.on('end', function () { log('close-cm5', Buffer.from('')); try { up.end(); } catch (e) {} });
      up.on('end', function () { log('close-cutter', Buffer.from('')); try { c.end(); } catch (e) {} });
      c.on('error', function () {}); up.on('error', function (e) { log('err', Buffer.from(String(e.code || e.message))); try { c.destroy(); } catch (x) {} upd(); });
      upd();
    });
    srv.on('error', function (e) { capStop('⚠ เปิดพอร์ต ' + lp + ' ไม่ได้ (' + (e.code || e.message) + ')'); });
    srv.listen(lp, '127.0.0.1', function () { upd(); });
    cap = { srv: srv, socks: [], fs: fs, fd: fd, file: file };
    $('capGo').textContent = 'หยุดดัก';
  };
  $('cutGo').onclick = function () {
    if (!job) return;
    var h = ip(), p = port();
    if (!validIp(h) || !p) { status('ตั้ง IP และพอร์ตก่อน (กด "ตรวจหา")', 'warn'); return; }
    if (!req()) { status('ใช้ได้เฉพาะใน Illustrator', 'warn'); return; }
    var b = $('cutGo');
    if (!b.classList.contains('arm')) {
      b.classList.add('arm'); b.textContent = 'กดอีกครั้งเพื่อตัด · ' + job.w.toFixed(0) + '×' + job.h.toFixed(0) + ' มม.';
      clearTimeout(armT); armT = setTimeout(disarm, 4000); return;
    }
    disarm(); b.disabled = true; status('กำลังส่งงานไป ' + h + ':' + p + ' …', '');
    send(h, p, job.data).then(function (n) {
      b.disabled = false;
      status('✓ ส่งแล้ว ' + Math.round(n / 1024 * 10) / 10 + ' KB · ' + job.n + ' เส้น', 'ok'); toast('✓ ส่งงานเข้าเครื่องตัดแล้ว');
    }, function (e) {
      b.disabled = false; status('⚠ ส่งไม่ได้: ' + e.message + ' · ถ้า Cutting Master เปิดค้างอยู่ให้ปิดก่อน', 'warn');
    });
  };
  function disarm() { clearTimeout(armT); var b = $('cutGo'); b.classList.remove('arm'); b.textContent = 'ส่งตัด'; }

  langUI(); draw();
})();
